package com.sas_apps.quickblox.utils;
/*
 * Created by Shashank Shinde.
 */

public class Utils {

    public static final String APP_ID = "68714";
    public static final String AUTH_KEY = "6PJgPAtNJ5pFg59";
    public static final String AUTH_SECRET = "eXWeP-UgYJaqywR";
    public static final String ACCOUNT_KEY = "D7Gr3HqLsqwr4pGUmAoP";

    public static final String CHAT_INTENT = "chat";
}
